package com.skillcube.driver.exception;

public class DriverNotFoundException extends Exception{

	public DriverNotFoundException(String message) {

	}
}
