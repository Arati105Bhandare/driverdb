package com.skillcube.driver.util;

public class AppConstant {

	public static String dbURL = "jdbc:mysql://localhost:3306/driverdb";
	public static String username = "root";
	public static String password = "Pooja"; 

}
