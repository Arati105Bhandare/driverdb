package com.skillcube.driver.exception;

public class DuplicateDriverIdException extends Exception {

	public DuplicateDriverIdException(String message) {
		
	}
}
